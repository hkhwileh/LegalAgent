import os
import torch
from transformers import pipeline
from langchain.text_splitter import RecursiveCharacterTextSplitter
import arabic_reshaper
from bidi.algorithm import get_display
import re

def test_summarization():
    # Create a sample text with both English and Arabic content
    test_text = """
    This is a test document containing both English and Arabic text.
    The purpose is to verify the summarization functionality.
    We want to ensure it handles both languages correctly.
    
    هذا نص تجريبي يحتوي على محتوى باللغتين العربية والإنجليزية.
    الغرض هو التحقق من وظيفة التلخيص.
    نريد التأكد من أنه يتعامل مع كلا اللغتين بشكل صحيح.
    
    The document continues with more content to ensure proper chunking.
    We need enough text to trigger the batch processing mechanism.
    This helps us verify that memory management is working as expected.
    
    يستمر المستند بمزيد من المحتوى للتأكد من التجزئة المناسبة.
    نحتاج إلى نص كافٍ لتفعيل آلية معالجة الدفعات.
    هذا يساعدنا في التحقق من أن إدارة الذاكرة تعمل كما هو متوقع.
    """
    
    try:
        # Initialize text splitter
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=500,
            chunk_overlap=50,
            length_function=len,
            separators=["\n\n", "\n", " ", ""]
        )
        
        # Initialize summarizer
        summarizer = pipeline(
            "summarization",
            model="sshleifer/distilbart-cnn-6-6",
            device="cpu",
            torch_dtype=torch.float32,
            batch_size=1
        )
        
        # Split text into chunks
        chunks = text_splitter.split_text(test_text)
        if not chunks:
            return False
            
        summaries = []
        total_chunks = len(chunks)
        
        # Process chunks in batches
        batch_size = 2
        for i in range(0, total_chunks, batch_size):
            # Clear memory
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            elif torch.backends.mps.is_available():
                import gc
                gc.collect()
                torch.mps.empty_cache()
            
            batch = chunks[i:i + batch_size]
            for chunk in batch:
                if not chunk.strip():
                    continue
                    
                try:
                    # Determine if chunk is primarily Arabic
                    is_arabic = any(ord(c) >= 0x0600 and ord(c) <= 0x06FF for c in chunk)
                    
                    # Adjust summary parameters based on text type
                    max_length = 150 if is_arabic else 130
                    min_length = 40 if is_arabic else 30
                    
                    # Generate summary
                    summary = summarizer(
                        chunk,
                        max_length=max_length,
                        min_length=min_length,
                        do_sample=False,
                        num_beams=1,
                        early_stopping=True,
                        truncation=True
                    )
                    
                    summary_text = summary[0]['summary_text'].strip()
                    if summary_text:
                        summaries.append(summary_text)
                        
                except Exception as e:
                    print(f"Warning: Error summarizing chunk: {str(e)}")
                    # Include a portion of the original text
                    summaries.append(chunk[:200] + "...")
            
            # Print progress
            progress = min(0.3 + (i / total_chunks) * 0.4, 0.7)
            print(f"Processing... {progress * 100:.1f}%")
        
        if not summaries:
            print("No summaries generated")
            return False
        
        # Combine summaries
        final_summary = " ".join(summaries)
        
        # Clean and process the final summary
        final_summary = re.sub(r'\s+', ' ', final_summary)
        final_summary = re.sub(r'\n\s*\n', '\n\n', final_summary)
        
        # Process Arabic text
        try:
            reshaped_text = arabic_reshaper.reshape(final_summary)
            final_summary = get_display(reshaped_text)
        except Exception as e:
            print(f"Warning: Error in Arabic text processing: {str(e)}")
        
        print("\nSummarization Result:")
        print("-" * 50)
        print(final_summary)
        print("-" * 50)
        return True
        
    except Exception as e:
        print(f"Error during testing: {str(e)}")
        return False

if __name__ == "__main__":
    success = test_summarization()
    print(f"\nTest {'succeeded' if success else 'failed'}")